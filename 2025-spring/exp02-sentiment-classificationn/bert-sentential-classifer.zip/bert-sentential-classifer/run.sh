export HF_ENDPOINT=https://hf-mirror.com
python main.py